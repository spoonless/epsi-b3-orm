package fr.epsi.b3.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import fr.epsi.b3.modele.DonneesPersonnelles;

@Controller
public class HelloController {

	@GetMapping("/hello")
	public String sayHello(DonneesPersonnelles donneesPersonnelles) {
		return "hello";
	}
	
}
