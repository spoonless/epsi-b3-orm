package fr.epsi.b3.controller;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import fr.epsi.b3.modele.DonneesPersonnelles;

@Controller
public class DonneesPersonnellesController {

	@GetMapping("/inscription")
	public String afficherFormulaire(DonneesPersonnelles donneesPersonnelles) {
		donneesPersonnelles.setNom("David");
		return "inscription";
	}
	
	@PostMapping("/traiter-inscription")
	public String traiterFormulaire(DonneesPersonnelles donneesPersonnelles, BindingResult bindResult) {
		// Dans la vraie vie : là on écrit du code
		return "hello";
	}
	
}
